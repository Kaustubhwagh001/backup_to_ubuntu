// Online Go compiler to run Golang program online
// Print "Hello World!" message

package main
import "fmt"

func main() {
  fmt.Println("Hello World!")
  fmt.Println(1+2)
  var name string
  fmt.Print("first enter name")
  fmt.Scanln(&name)
  fmt.Println("hello!",name)
  var num =42
  var result string
  if num<=0{
      result="less than zero"
  } else if num==0{
      result="equal to zero"
  }else{
      result="greater than zero"
  }
 
  fmt.Println(result)
  //+++++++++++++++++++++++++++++++++++++++
  var day int
  fmt.Println("enter the day")
  fmt.Scanln(&day)
  var result_day string
  switch day{
       case 1:
       result_day="monday"
       case 2:
       result_day="tuesday"
       case 3:
       result_day="wednesday"
       case 4:
       result_day="thursday"
       case 5:
       result_day="friday"
       case 6:
       result_day="saturday"
       case 7:
       result_day="sunday"
       default:
       result_day="invaild day"
  }
  fmt.Println(result_day)
  //+++++++++++++++++++++++++++++++++++++++++++++++++
  colors3:= []string{"red","green","blue"}
  fmt.Println(colors3)
  for i:=0;i<len(colors3);i++{
      fmt.Println(colors3[i])
  }
    dosomething()
    sum:=addition(5,3)
        
         fmt.Println(sum)
//+++++++++++using user input
     var a, b int
    fmt.Println("enter two values")
    fmt.Scanln(&a,&b)
    sum1:=addition(a,b)
    fmt.Println(sum1)

   
}
func dosomething(){
    fmt.Println("This is something")
}
func addition(value1 int,value2 int)int{
    return value1+value2
}