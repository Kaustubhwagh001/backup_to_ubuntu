package main
import(
    "fmt" 
    "math"
    "time"
    "sort"
  //  "bufio"
  //  "io"
  ) 
// var aconst int=64
func main(){
    var afloat=3.14359
    var rounded=math.Round(afloat)
    fmt.Println("original: %v,Rounded: %v",afloat,rounded)
  //  var name string
   // var inta int =10
    //var intb float64=15.5
    //sum:=float64(inta)+intb
    //fmt.Println(sum)
    fmt.Println(5+22)
    i1,i2,i3:=15,20,30
    fmt.Println(i1+i2+i3)
    f1,f2,f3:=15.1,15.2,15.3
    sum:=f1+f2+f3
    fmt.Println(sum)
    sum=math.Round(sum*100)/100
    fmt.Println("flaot sum=",sum)
 //   var aString string="This is Go!"
 //   var aInteger int =40
 //   var bString ="another string!"
   // cString:="my name is joker"
    //fmt.Println("go")
    //fmt.Println(aString)
    //fmt.Println(bString)
    
    //fmt.Println(" The variable type is %T",aString)
  //  fmt.Println(cString)
//    fmt.Println(aInteger)
    //fmt.Println(aconst)
  //fmt.Scanln(&name)
   // fmt.Println("name is",name)
   n:=time.Now()
   fmt.Println(n)
   t:=time.Date(2007,time.October,10,23,0,0,0,time.UTC)
   fmt.Println(t)
   var paddress=50
   var p=&paddress
   fmt.Println("pointer=",*p)
   var colors[3] string
   colors[0]="red"
   colors[1]="green"
   colors[2]="blue"
   fmt.Println(colors)
   var numbers=[5]int {1,2,3,4,5}
   fmt.Println(numbers)
   fmt.Println("length of numbers array=",len(numbers))
   //***************************************************
   //Slices in go
   var colors1=[] string{"Violet","yellow","blue"}
   fmt.Println(colors1)
   colors1=append(colors1,"purple")
      fmt.Println(colors1)
    colors1=append(colors1[1:len(colors1)])      
    fmt.Println(colors1)
    numbers2 :=make([]int,5)
    numbers2[0]=22
    numbers2[1]=342
    numbers2[2]=23
    numbers2[3]=78
    numbers2[4]=22
    fmt.Println(numbers2)
    numbers2 =append(numbers2,30012)
    fmt.Println(numbers2)
    sort.Ints(numbers2)
    fmt.Println(numbers2)
    

      //++++++++++++++++++++++++++++++++++++++
      states:=make(map[string]string)
      fmt.Println(states)
      states["wa"]="washington"
      states["ca"]="california"
      states["no"]="neworleans"
      fmt.Println(states)
      california:=states["ca"]
      fmt.Println(california)
      delete(states,"ca")
      fmt.Println(states)
      
      for k,v:=range states{
          fmt.Println(k,v)
          }
          //++++++++++++++++adding its values to slices
          fmt.Println("after adding values to slices")
          keys:=make([]string,len(states))
          i:=0
          for k:=range states{
              keys[i]=k
          }
          fmt.Println(keys)
          sort.Strings(keys)
          fmt.Println(keys)
          for i:=range keys{
              fmt.Println(states[keys[i]])
          }
      }


      

   
