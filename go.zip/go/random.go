package main
import "fmt"
 var aconst int=64
func main(){
    var aString string="This is Go!"
    var aInteger int =40
    var bString ="another string!"
    cString:="my name is joker"
    fmt.Println("go")
    fmt.Println(aString)
    fmt.Println(bString)
    
    fmt.Println(" The variable type is %T",aString)
    fmt.Println(cString)
    fmt.Println(aInteger)
    fmt.Println(aconst)
}